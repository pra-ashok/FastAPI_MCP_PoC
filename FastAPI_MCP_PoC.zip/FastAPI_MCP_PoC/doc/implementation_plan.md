# FastAPI_MCP_PoC Implementation Plan

This plan outlines a modular, two-tier Python application with a dedicated Backend and Frontend.

## User Review Required

> [!IMPORTANT]
> The Backend (FastAPI) and Frontend (Python-based UI) will be separate processes. 
> A Vector Database (ChromaDB) will be integrated into the backend for "Knowledge Base" capabilities.

## Proposed Changes

### Backend (FastAPI + MCP + Vector DB)

#### [NEW] [vector_service.py](file:///home/ashok/Apps/Personal1/mcp-vectornexus/backend/vector_service.py)
Handles vector storage and similarity search using ChromaDB.

#### [NEW] [mcp_core.py](file:///home/ashok/Apps/Personal1/mcp-vectornexus/backend/mcp_core.py)
MCP server logic, now including tools to interact with the Vector DB.

#### [NEW] [requirements.txt](file:///home/ashok/Apps/Personal1/mcp-vectornexus/backend/requirements.txt)
Includes `chromadb` and `fastapi`.

### Frontend (Python-based UI)

#### [NEW] [main.py](file:///home/ashok/Apps/Personal1/mcp-vectornexus/frontend/main.py)
A separate Python application (using Streamlit or NiceGUI) for:
- Configuring the Backend.
- Monitoring metrics and logs.
- Testing Vector Search queries.

## Modular Component Breakdown

| Component | Responsibility | Technology |
| :--- | :--- | :--- |
| **Backend API** | MCP SSE, Vector Search, Config API | FastAPI |
| **MCP Server** | Tool/Resource handlers | MCP SDK |
| **Vector DB** | Document storage & retrieval | ChromaDB |
| **Dashboard** | Metrics, Monitoring, Config UI | Streamlit / NiceGUI |

## Verification Plan

### Automated Tests
- Test Backend API endpoints (SSE, Vector Search).
- Verify Frontend-Backend communication.

### Manual Verification
- Upload knowledge to Vector DB and query via MCP.
- Monitor metrics on the Dashboard.
